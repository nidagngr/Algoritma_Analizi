using System;

class MatrixMultiplication
{
    static void Main()
    {
        int[,] matrix1 = { {1, 2}, {3, 4} }; // Tn: O(1),On: O(n^2)
        int[,] matrix2 = { {5, 6}, {7, 8} }; // Tn: O(1), On: O(n^2)

        int[,] result = MultiplyMatrices(matrix1, matrix2); // Tn: O(n^3), On: O(n^2)

        Console.WriteLine("Sonuç:"); // Tn: O(1), On: O(1)
        PrintMatrix(result); // Tn: O(n^2), On: O(n^2)
    }

    static int[,] MultiplyMatrices(int[,] matrix1, int[,] matrix2)
    {
        int rows1 = matrix1.GetLength(0); // Tn: O(1), On: O(1)
        int cols1 = matrix1.GetLength(1); // Tn: O(1), On: O(1)
        int rows2 = matrix2.GetLength(0); // Tn: O(1), On: O(1)
        int cols2 = matrix2.GetLength(1); // Tn: O(1), On: O(1)

        if (cols1 != rows2)
        {
            throw new ArgumentException("Matrisler çarpılamaz."); // Tn: O(1), On: O(1)
        }

        int[,] result = new int[rows1, cols2]; // Tn: O(n^2), On: O(n^2)

        for (int i = 0; i < rows1; i++) // Tn: O(n), On: O(n)
        {
            for (int j = 0; j < cols2; j++) // Tn: O(n), On: O(n)
            {
                int sum = 0; // Tn: O(1), On: O(1)
                for (int k = 0; k < cols1; k++) // Tn: O(n), On: O(n)
                {
                    sum += matrix1[i, k] * matrix2[k, j]; // Tn: O(1), On: O(1)
                }
                result[i, j] = sum; // Tn: O(1), On: O(1)
            }
        }

        return result; // Tn: O(1), On: O(1)
    }

    static void PrintMatrix(int[,] matrix)
    {
        int rows = matrix.GetLength(0); // Tn: O(1), On: O(1)
        int cols = matrix.GetLength(1); // Tn: O(1), On: O(1)

        for (int i = 0; i < rows; i++) // Tn: O(n), On: O(n)
        {
            for (int j = 0; j < cols; j++) // Tn: O(n), On: O(n)
            {
                Console.Write(matrix[i, j] + " "); // Tn: O(1), On: O(1)
            }
            Console.WriteLine(); // Tn: O(1), On: O(1)
        }
    }
}
