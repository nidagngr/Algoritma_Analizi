using System;

class MatrixMultiplication
{
    static void Main()
    {
        int[,] matrix1 = { {1, 2}, {3, 4} }; // Tn: O(1), On: O(n^2)
        int[,] matrix2 = { {5, 6}, {7, 8} }; // Tn: O(1), On: O(n^2)

        int[,] result = MultiplyMatrices(matrix1, matrix2); // Tn: O(n^3), On: O(n^2)

        Console.WriteLine("Sonuç:"); // Tn: O(1), On: O(1)
        PrintMatrix(result); // Tn: O(n^2), On: O(n^2)
    }

    static int[,] MultiplyMatrices(int[,] matrix1, int[,] matrix2)
    {
        int rows1 = matrix1.GetLength(0); // Tn: O(1), On: O(1)
        int cols1 = matrix1.GetLength(1); // Tn: O(1), On: O(1)
        int rows2 = matrix2.GetLength(0); // Tn: O(1), On: O(1)
        int cols2 = matrix2.GetLength(1); // Tn: O(1), On: O(1)

        if (cols1 != rows2)
        {
            throw new ArgumentException("Matrisler çarpılamaz."); // Tn: O(1), On: O(1)
        }

        int[,] result = new int[rows1, cols2]; // Tn: O(n^2), On: O(n^2)

        Multiply(matrix1, matrix2, result, rows1, cols1, cols2, 0, 0, 0); // Tn: O(n^3), On: O(n^3)

        return result; // Tn: O(1), On: O(1)
    }

    static void Multiply(int[,] matrix1, int[,] matrix2, int[,] result, int rows1, int cols1, int cols2, int i, int j, int k)
    {
        if (i >= rows1)
            return; // Tn: O(1), On: O(1)

        if (j < cols2)
        {
            if (k < cols1)
            {
                result[i, j] += matrix1[i, k] * matrix2[k, j]; // Tn: O(1), On: O(1)
                Multiply(matrix1, matrix2, result, rows1, cols1, cols2, i, j, k + 1); // Tn: O(n^3), On: O(n^3)
            }
            Multiply(matrix1, matrix2, result, rows1, cols1, cols2, i, j + 1, 0); // Tn: O(n^3), On: O(n^3)
        }
        Multiply(matrix1, matrix2, result, rows1, cols1, cols2, i + 1, 0, 0); // Tn: O(n^3), On: O(n^3)
    }

    static void PrintMatrix(int[,] matrix)
    {
        int rows = matrix.GetLength(0); // Tn: O(1), On: O(1)
        int cols = matrix.GetLength(1); // Tn: O(1), On: O(1)

        for (int i = 0; i < rows; i++) // Tn: O(n), On: O(n)
        {
            for (int j = 0; j < cols; j++) // Tn: O(n), On: O(n)
            {
                Console.Write(matrix[i, j] + " "); // Tn: O(1), On: O(1)
            }
            Console.WriteLine(); // Tn: O(1), On: O(1)
        }
    }
}
