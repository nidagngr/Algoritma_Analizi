using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Faktöriyelini hesaplamak istediğiniz sayıyı girin: "); //1
        int sayi = Convert.ToInt32(Console.ReadLine());

        long faktoriyel = 1; // 1

        for (int i = 1; i <= sayi; i++) // n kez döner
        {
            faktoriyel *= i; // n kez döner 
        }

        Console.WriteLine("{0} sayısının faktöriyeli: {1}", sayi, faktoriyel); // 1
    }                                                                           // T(n)=n+4
}                                                                                // O(n)=n
