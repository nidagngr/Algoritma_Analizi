using System;

class Program
{
    static void Main(string[] args) // 1
    {
        Console.Write("Faktöriyelini hesaplamak istediğiniz sayıyı girin: "); //1
        int sayi = Convert.ToInt32(Console.ReadLine()); //1

        long faktoriyel = FaktoriyelHesapla(sayi);  // n

        Console.WriteLine("{0} sayısının faktöriyeli: {1}", sayi, faktoriyel);
    }

    static long FaktoriyelHesapla(int n)  
    {
        if (n == 0)  // 1 
            return 1; //1
        else
            return n * FaktoriyelHesapla(n - 1); // (n-1)
                                              //T(n) =2+ T(n-1)
    }
}
